def cadena_invertida_rec(cadena):
    if len(cadena) == 0:
        return cadena
    else:
        return cadena_invertida_rec(cadena[1:]) + cadena[0]
    
cadena_original = "David Saipert"
cadena_invertida = cadena_invertida_rec(cadena_original)
print("La cadena original es: ", cadena_original)
print("La cadena invertida es: ", cadena_invertida)