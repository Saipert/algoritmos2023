def contar_digitos(num):
    if num < 10:
        return 1
    else:
        return 1 + contar_digitos(num // 10)
    
num = int(input("Ingrese un numero entero: "))
cant_digitos = contar_digitos(num)
print("El numero", num, "tiene", cant_digitos, "digitos.")