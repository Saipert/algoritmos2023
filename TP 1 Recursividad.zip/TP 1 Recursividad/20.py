def centinela(lista, valor, indice=0):

    if lista[indice] == valor:
        return True
    elif lista[indice] == None:
        return False
    else:
        return centinela(lista, valor, indice+1)

# Ejemplo de uso
lista = [1, 3, 5, 7, 9, None]
valor = int(input("Indique un valor para ver si esta en la lista: "))
resultado = centinela(lista, valor)
if resultado:
    print(f"El valor {valor} está en la lista")
else:
    print(f"El valor {valor} no está en la lista")
