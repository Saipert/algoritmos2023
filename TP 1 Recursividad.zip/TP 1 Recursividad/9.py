def log_entero(n, b):
    if n < b:
        return 0
    else:
        return 1 + log_entero(n // b, b)
    
n = int(input("Ingrese un numero entero: "))
b = int(input("Ingrese la base del logaritmo: "))
log_n_b = log_entero(n, b)
print("El logaritmo entero de ", n, "en base ", b, "es: ", log_n_b)