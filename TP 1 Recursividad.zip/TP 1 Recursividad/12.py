def euclides(a, b):
    if b == 0:
        return a
    else:
        return euclides(b, a % b)

a = int(input("Ingrese un numero entero: "))
b = int(input("Ingrese otro numero entero: "))
mcd = euclides(a, b)
print ("El Minimo Comun Divisor de", a, "y", b, "es", mcd)