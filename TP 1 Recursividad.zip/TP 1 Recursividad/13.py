def euclides(a, b):
    if b == 0:
        return a
    else:
        return euclides(b, a % b)
    
def mcm(a, b):
    return abs(a * b) // euclides(a, b)

a = int(input("Ingrese un numero entero: "))
b = int(input("Ingrese otro numero entero: "))
print (mcm(a, b))