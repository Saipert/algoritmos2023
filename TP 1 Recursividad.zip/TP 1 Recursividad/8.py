def decimal_binario(n):
    if n <= 1:
        return str(n)
    else:
        return decimal_binario(n // 2) + str(n % 2)
    
num_decimal = int(input("Ingrese un numero entero: "))
num_binario = decimal_binario(num_decimal)
print("El numero", num_decimal, "en sistema binario es:", num_binario)
                

