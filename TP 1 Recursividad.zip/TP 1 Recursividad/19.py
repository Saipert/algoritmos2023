def sucesion(n):
    if n == 1:
        return 2
    else:
        return (n+1)/sucesion(n-1)

n = int(input("Indique el valor de n: "))
valor = sucesion(n)
print(f"El valor de f({n}) en la sucesión es: {valor}")
