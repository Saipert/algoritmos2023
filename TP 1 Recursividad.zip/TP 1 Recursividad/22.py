def jedi(mochila, indice=0, contador=0):
   
    if indice == len(mochila):  # se llegó al final de la mochila sin encontrar el sable de luz
        return None
    elif mochila[indice] == "sable de luz":  # se encontró el sable de luz
        return contador+1
    else:  # aún quedan objetos por sacar de la mochila
        return jedi(mochila, indice+1, contador+1)

mochila = ["comida", "agua", "sable de luz", "ropa", "medicina"]
objetos_sacados = jedi(mochila)
if objetos_sacados is not None:
    print(f"Se encontró el sable de luz después de sacar {objetos_sacados} objetos de la mochila")
else:
    print("No se encontró el sable de luz en la mochila")
