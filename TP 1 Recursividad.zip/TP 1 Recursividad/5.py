def romano_a_decimal(romano):
    if not romano:
        return 0
    elif romano[0] == 'M':
        return 1000 + romano_a_decimal(romano[1:])
    elif romano[0] == 'D':
        return 500 + romano_a_decimal(romano[1:])
    elif romano[0] == 'C':
        if len(romano) > 1 and romano[1] == 'M':
            return 900 + romano_a_decimal(romano[2:])
        elif len(romano) > 1 and romano[1] == 'D':
            return 400 + romano_a_decimal(romano[2:])
        else:
            return 100 + romano_a_decimal(romano[1:])
    elif romano[0] == 'L':
        return 50 + romano_a_decimal(romano[1:])
    elif romano[0] == 'X':
        if len(romano) > 1 and romano[1] == 'C':
            return 90 + romano_a_decimal(romano[2:])
        elif len(romano) > 1 and romano[1] == 'L':
            return 40 + romano_a_decimal(romano[2:])
        else:
            return 10 + romano_a_decimal(romano[1:])
    elif romano[0] == 'V':
        return 5 + romano_a_decimal(romano[1:])
    elif romano[0] == 'I':
        if len(romano) > 1 and romano[1] == 'X':
            return 9 + romano_a_decimal(romano[2:])
        elif len(romano) > 1 and romano[1] == 'V':
            return 4 + romano_a_decimal(romano[2:])
        else:
            return 1 + romano_a_decimal(romano[1:])

num_romano = input("Ingrese un número romano: ")
num_decimal = romano_a_decimal(num_romano)
print("El número romano", num_romano, "equivale a", num_decimal, "en sistema decimal.")