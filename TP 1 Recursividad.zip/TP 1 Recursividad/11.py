def invertir_numero(n):
    if n < 10:
        return n
    else:
        ultimo_digito = n % 10
        resto_numero = n // 10
        long_resto = len(str(resto_numero))
        return ultimo_digito * (10 ** long_resto) + invertir_numero(resto_numero)

numero = int(input("Ingrese un numero entero: "))
numero_invertido = invertir_numero(numero)
print ("El numero", numero, "invertido es", numero_invertido)