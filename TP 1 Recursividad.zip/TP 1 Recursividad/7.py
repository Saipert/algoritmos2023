def h(n):
    if n == 1:
        return 1
    else:
        return 1/n + h(n-1)
    
n = int(input("Ingrese un numero entero para calcular la serie h(n): "))
serie = h(n)
print ("La serie h(", n,") es:", serie)