def vector_inv(vector, indice):
    if indice >= 0:
        print(vector[indice])
        vector_inv(vector, indice - 1)
       
n1 = int(input("Escriba a continuacion el primer numero del vector: "))
n2 = int(input("Escriba a continuacion el segundo numero del vector: "))
n3 = int(input("Escriba a continuacion el tercer numero del vector: "))
n4 = int(input("Escriba a continuacion el cuarto numero del vector: "))
n5 = int(input("Escriba a continuacion el quinto numero del vector: "))

vector = [n1, n2, n3, n4, n5]
vector_inv(vector, len(vector) - 1)