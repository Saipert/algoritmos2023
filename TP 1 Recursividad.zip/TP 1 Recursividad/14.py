def suma_digitos(n):
    if n == 0:
        return 0
    else:
        return n % 10 + suma_digitos(n // 10)
    
n = int(input("Escribe un numero entero: "))
print("La suma de sus digitos da como resultado: ", suma_digitos(n))