def sucesion_geometrica(a1, r, n):
    if n == 1:
        return a1
    else:
        return r * sucesion_geometrica(a1, r, n-1)

a1= 2
r = -3
n = int(input("Seleccione un numero entero: "))

for i in range(1, n+1):
    an = sucesion_geometrica(a1, r, i)
    print("a" + str(i) + " = " + str(an))
    
