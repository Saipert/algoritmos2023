def busqueda_binaria_recursiva(lista, valor, inicio=0, fin=None):
    if fin is None:
        fin = len(lista) - 1
    
    if inicio > fin:
        return False

    medio = (inicio + fin) // 2
    if lista[medio] == valor:
        return True
    elif valor < lista[medio]:
        return busqueda_binaria_recursiva(lista, valor, inicio, medio-1)
    else:
        return busqueda_binaria_recursiva(lista, valor, medio+1, fin)

lista = []
lista.append(1)
lista.append(3)
lista.append(5)
lista.append(7)
lista.append(9)
valor = int(input("Indique un valor para ver si esta en la lista: "))
resultado = busqueda_binaria_recursiva(lista, valor)
if resultado == True:
    print(f"El valor {valor} está en la lista")
elif resultado == False:
    print(f"El valor {valor} no está en la lista")
else:
    print(f"Error: el resultado ({resultado}) no es booleano")