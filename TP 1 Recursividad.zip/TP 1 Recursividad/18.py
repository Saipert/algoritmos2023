def matriz(mat, fila=0, columna=0):
    if columna == len(mat[fila]):
        fila += 1
        columna = 0
    if fila == len(mat):
        return
    
    print(mat[fila][columna], end=' ')
    matriz(mat, fila, columna+1)

a = int(input("Ingrese los valores de la matriz: "))
b = int(input(""))
c = int(input(""))
d = int(input(""))
e = int(input(""))
f = int(input(""))
g = int(input(""))
h = int(input(""))
i = int(input(""))

mat = [[a, b, c],
       [d, e, f],
       [g, h, i]]
    
matriz(mat)