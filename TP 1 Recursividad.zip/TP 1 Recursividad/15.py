def raiz_cuadrada(n):
    if n == 0:
        return 0
    else:
        return raiz_cuadrada_aux(n, n // 2)
    
def raiz_cuadrada_aux(n, aux):
    if aux*aux <= n < (aux+1)*(aux+1):
        return aux
    elif n < aux*aux:
        return raiz_cuadrada_aux(n, aux // 2)
    else:
        return raiz_cuadrada_aux(n, (aux + n//aux)//2)

n = int(input("Ingrese un numero entero para calcular su raiz, o su entero aproximado: "))
print(raiz_cuadrada(n))